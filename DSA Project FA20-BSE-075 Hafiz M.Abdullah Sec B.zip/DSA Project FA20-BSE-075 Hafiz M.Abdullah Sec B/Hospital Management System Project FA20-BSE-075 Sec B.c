// Hospital Management System //
// FA20-BSE-075 Hafiz Muhammad Abdullah //
// Sec B //
#include <stdio.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#define SIZE 20
struct node{ // Structure for patient appointment
    int priority;
    char name[SIZE];
    char category[10];
    char OPD[15];
    struct node *address;
};
struct doc{ // Structure for Doctors
    int strength;
    char specialization[SIZE];
    struct doc *address;
};
struct nurse{ // Structure for Nurses
    int strength;
    char Ward[SIZE];
    struct doc *address;
};
struct equip{ // Structure for Hospital Equipment
    int strength;
    char equipment[SIZE];
    struct equip *address;
};
struct ward{ // Structure for Hospital Wards and ICUs
    int strength;
    char WardType[SIZE];
    struct ward *address;
};
struct node *Vip1 = NULL;  //Pointer for 1st VIP patients List
struct node *Vip2 = NULL;  //Pointer for 2nd VIP patients List
struct node *Regular1 = NULL; //Pointer for 1st Regular patients List
struct node *Regular2 = NULL; //Pointer for 2nd Regular patients List
struct doc *DocHead = NULL;  // Pointer for Doctors List
struct nurse *NurseHead = NULL;// Pointer for Nurses List
struct equip *EqpHead = NULL; // Pointer for Hospital Equipment List
struct ward *WardHead = NULL; // Pointer for Hospital wards and ICUs List
int VipCounter,RegularCounter,Vip2Counter,Regular2Counter = 0;  // Counters are used to record number of patients in each list
int Vcount = 1,Rcount=1;   // Counters Used in Updating the record after conduction of appointments
int numOfPatients = 10;
void bookAppointment(char name[20], int priority,char OPD[15]);
void manageDoctors(char s[SIZE]);
void display(struct node *head);
void displayDoctors(struct doc *head);
void displayNurses(struct nurse *head);
void displayWards(struct ward *head);
void displayEquipment(struct equip *head);
int nameComparison(char name[SIZE],struct node *List);          /*Functions  for the comparisons */
int SpecializationComparison(char name[SIZE],struct doc *List);
int WardComparison(char name[SIZE],struct nurse *List);
int EquipmentComparison(char name[SIZE],struct equip *List);
void UpdateRecord(char name[20], int i);
int returnPriority(char name[SIZE],struct node *List);

void manageNurses(char ward[SIZE]);

void manageEquipment(char equipment[20]);

void manageWards(char type[20]);

void saveToFile(struct node *head,char file[]);

struct node *ReadFromFile(struct node *head,char filename[]);

int fileComparison(char *filename, const char *string);

int main() {
    int choice,category,ch,ListChoice,ManageChoice,ManageStaff; // Choices declarations to be used in Switch statements
    char Name[SIZE],specialization[SIZE],Ward[SIZE],Equipment[SIZE],WardType[SIZE],OPD[SIZE];  // Arrays Declarations
    // Read Data from files as soon as program is loaded
    Vip1 = ReadFromFile(Vip1,"VIP1stList_file.csv");
    Vip2 =  ReadFromFile(Vip2,"VIP2ndList_file.csv");
    Regular1 = ReadFromFile(Regular1,"Regular1stList_file.csv");
    Regular2 =  ReadFromFile(Regular2,"Regular2ndList_file.csv");
    printf("---------------------------------------------------------------------------------------------------\n");
    printf("                                        Hospital Management System                                 \n");
    printf("                                        Hafiz Muhammad Abdullah                                    \n");
    printf("                                        FA20-BSE-075 Sec B                                         \n");
    printf("---------------------------------------------------------------------------------------------------\n");
    do {
        printf("\n----------------->Menu<------------------");
        printf("\n1-Manage Appointments\n2-Manage Hospital staff\n3-Manage Hospital Equipment\n4-Manage Hospital Wards and ICUs\n5-Show Records\n6-Exit (Data Store in Files)");
        scanf("%d", &choice);
        fflush(stdin);
        switch (choice) {
            case 1:
                printf("\n1-Add Appointment\n2-Update Appointment Record");
                scanf("%d",&ManageChoice);
                fflush(stdin);
                switch (ManageChoice) {
                    case 1:
                    printf("\nEnter patient name :");
                    gets(Name);
                    printf("\nEnter Patient respective OPD:");
                    gets(OPD);
                    printf("\nSelect patient Category :");
                    printf("\n1-VIP\n2-Regular");
                    scanf("%d", &category);
                        fflush(stdin);
                        switch (category) {
                        case 1:
                            bookAppointment(Name, 1,OPD); // Book appointment function call for VIP patients
                            break;
                        case 2:
                            bookAppointment(Name, 2,OPD); // Book appointment function call for Regular Patients
                            break;
                        default:
                            printf("\nEnter the valid priority option!");
                    }
                    break;
                    case 2:
                        printf("\nEnter the name of patient came for Appointment");
                        gets(Name);
                        printf("\nSelect patient Category came for appointment:");
                        printf("\n1-VIP\n2-Regular");
                        scanf("%d", &category);
                        fflush(stdin);
                        switch (category) {
                            case 1:
                                UpdateRecord(Name, 1);  // Update VIP patients list function call
                                break;
                            case 2:
                                UpdateRecord(Name, 2);  // Update Regular patients list function call
                                break;
                            default:
                                printf("\nEnter the valid Category option!");
                        }
                        break;
                    default:
                        printf("Enter the valid Manage Appointment choice!");
                }
                break;
            case 2:
                printf("\n1-Manage Doctors\n2-Manage Nurses");
                scanf("%d",&ManageStaff);
                fflush(stdin);
                switch (ManageStaff) {
                    case 1:
                        printf("\nEnter the specialization of respective doctor :");
                        gets(specialization);
                        manageDoctors(specialization); // Manage Doctors according to their specialization
                        break;
                    case 2:
                        printf("\nEnter the duty ward of respective Nurse VIP/General/ICU:");
                        gets(Ward);
                        manageNurses(Ward); // Manage Nurses according to their Duty wards
                        break;
                    default:
                        printf("\nEnter valid Manage staff choice!");
                }
                break;
            case 3:
                printf("\nEnter the equipment to be added in Equipment records :");
                gets(Equipment);
                manageEquipment(Equipment); // Manage Hospital Equipment according to their Names
                break;
            case 4:
                printf("\nEnter the ward types to be added in records of each categories (VIP/General/ICU):");
                gets(WardType);
                manageWards(WardType); // Manage Hospital Wards according to their Type
                break;
            case 5:
                printf("\nWhich List you want to display?");
                printf("\n1-VIP\n2-Regular\n3-Doctors\n4-Nurses\n5-Hospital Equipment\n6-Wards");
                scanf("%d",&ch);
                fflush(stdin);
                switch (ch) {
                    case 1:
                        printf("\nWhich VIP List you want to display?");
                        printf("\n1-VIP 1st\n2-VIP 2nd");
                        scanf("%d",&ListChoice);
                        fflush(stdin);
                        switch (ListChoice) {
                            case 1:
                                display(Vip1);  // Display VIP patients 1st List
                                break;
                            case 2:
                                display(Vip2); // Display VIP patients 2nd List
                                break;
                            default:
                                printf("\nEnter the valid List option!");
                        }
                        break;
                    case 2:
                        printf("\nWhich Regular List you want to display?");
                        printf("\n1-Regular 1st\n2-Regular 2nd");
                        scanf("%d",&ListChoice);
                        fflush(stdin);
                        switch (ListChoice) {
                            case 1:
                                display(Regular1); // Display Regular patients 1st List
                                break;
                            case 2:
                                display(Regular2); // Display Regular patients 2nd List
                                break;
                            default:
                                printf("\nEnter the valid List option!");
                        }
                        break;
                    case 3:
                        displayDoctors(DocHead);  // Display Doctors List according to specialization
                        break;
                    case 4:
                        displayNurses(NurseHead); // Display Nurses List according to their duty wards
                        break;
                    case 5:
                        displayEquipment(EqpHead); // Display Hospital equipment record
                        break;
                    case 6:
                        displayWards(WardHead); // Display Hospital Wards Record
                        break;
                    default:
                        printf("\nEnter the valid List option!");
                }
                break;
            case 6:
                // Exit is called to store the data in files and then exit from program
                saveToFile(Vip1,"VIP1stList_file.csv");  // Two VIPs list and Two Regular Patients lists
                saveToFile(Vip2,"VIP2ndList_file.csv");
                saveToFile(Regular1,"Regular1stList_file.csv");
                saveToFile(Regular2,"Regular2ndList_file.csv");
                printf("Data Stored Successfully\n");
                exit(0);
            default:
                printf("\nEnter the valid Menu option!");
        }
    } while (choice!=-1);  // Enter choice -1 to exit without saving data in files
}

struct node *ReadFromFile(struct node *List,char filename[]) {
    struct node* temp = (struct node *)malloc(sizeof(struct node));
    struct node* head;
    struct node* last;
    last = head = NULL;
    FILE* file;
    file = fopen (filename, "r");
    if (file == NULL)
    {
        fprintf(stderr, "\nNo File Found'\n");
    }
    // reading nodes from the file
    // nodes are read in the same order as they were stored
    // we are using the data stored in the file to create a new linked list
    while(fread(temp, sizeof(struct node), 1, file))
    {
        if(head==NULL)
        {
            head = last = (struct node *)malloc(sizeof(struct node));
        }
        else
        {
            last->address = (struct node *)malloc(sizeof(struct node));
            last = last->address;
        }
        List = head;
        last->priority = temp->priority;
        strcpy(last->name, temp->name);
        strcpy(last->category,temp->category);
        strcpy(last->OPD,temp->OPD);
        if((fileComparison(filename,"VIP1stList_file.csv"))==0){
            VipCounter = last->priority;                              // Files comparison to update the patients list counters
            Vcount = List->priority;
        }
        if((fileComparison(filename,"VIP2ndList_file.csv"))==0){
            Vip2Counter = last->priority;
        }
        if((fileComparison(filename,"Regular1stList_file.csv"))==0){
            RegularCounter = last->priority;
            Rcount = List->priority;
        }
        if((fileComparison(filename,"Regular2ndList_file.csv"))==0){
            Regular2Counter = last->priority;
        }
        last->address = NULL;
    }
    fclose(file);
    return List;
}

int fileComparison(char *filename, const char *string) {  // Files comparison to know the file from which data is being read.
    int com;
    com=strcmp(filename,string);
    if(com==0){
        return 0;
    } else
        return -1;
}

void saveToFile(struct node *head,char List[]) {
    struct node *p = head;
    FILE *file;
    file = fopen(List,"w");
    if(file==NULL){
        fprintf(stderr,"\nCould not open the file");
        exit(1);
    }
    while (p!=NULL){
        fwrite(p,sizeof (struct node),1,file);  // Write all nodes data to file
        p = p->address;
    }
    fclose(file);
}

void manageWards(char WardType[SIZE]) { // Function to Manage Wards and ICUs
    struct ward *z = WardHead;
    int com;
    if(z==NULL){
        struct ward *temp = (struct ward *)malloc(sizeof (struct ward));
        temp->strength = 1;
        strcpy(temp->WardType,WardType);
        temp->address = NULL;
        WardHead = temp;
        printf("\nHospital Wards record updated!");
    } else {
        while (z->address != NULL) {
            z = z->address;
        }
        com = WardComparison(WardType,WardHead);  // Function to compare Wards names to increment the strength of a certain ward if they have same name.
        if (com == 0) {
            printf("\nHospital Wards record updated!");
        } else {
            struct ward *temp = (struct ward *) malloc(sizeof(struct ward));
            temp->strength = 1;
            strcpy(temp->WardType,WardType);
            z->address = temp;
            temp->address = NULL;
            printf("\nHospital Wards record updated!");
        }
    }
}
void manageEquipment(char equipment[SIZE]) {  // Function to Manage Hospital Equipment
    struct equip *z = EqpHead;
    int com;
    if(z==NULL){
        struct equip *temp = (struct equip *)malloc(sizeof (struct equip));
        temp->strength = 1;
        strcpy(temp->equipment,equipment);
        temp->address = NULL;
        EqpHead = temp;
        printf("\nEquipment record updated!");
    } else {
        while (z->address != NULL) {
            z = z->address;
        }
        com = EquipmentComparison(equipment,EqpHead); // Function to compare Equipment names to increment the strength of a certain equipment if they have same name.
        if (com == 0) {
            printf("\nEquipment record updated!");
        } else {
            struct equip *temp = (struct equip *) malloc(sizeof(struct equip));
            temp->strength = 1;
            strcpy(temp->equipment,equipment);
            z->address = temp;
            temp->address = NULL;
            printf("\nEquipment record updated!");
        }
    }
}

void manageNurses(char ward[SIZE]) { // Function to Manage Hospital Nurses
    struct nurse *z = NurseHead;
    int com;
    if(z==NULL){
        struct nurse *temp = (struct nurse *)malloc(sizeof (struct nurse));
        temp->strength = 1;
        strcpy(temp->Ward,ward);
        temp->address = NULL;
        NurseHead = temp;
        printf("\nNurses Record updated!");
    } else {
        while (z->address != NULL) {
            z = (struct nurse *) z->address;
        }
        com = WardComparison(ward,NurseHead); // Function to compare wards names to increment the strength of nurses in a duty ward if they have same ward name.
        if (com == 0) {
            printf("\nNurses Record updated!");
        } else {
            struct nurse *temp = (struct nurse *) malloc(sizeof(struct nurse));
            temp->strength = 1;
            strcpy(temp->Ward,ward);
            z->address = temp;
            temp->address = NULL;
            printf("\nNurses Record updated!");
        }
    }
}

void manageDoctors(char specialization[SIZE]){  // Function to Manage Hospital Doctors
    struct doc *z = DocHead;
    int com;
    if(z==NULL){
        struct doc *temp = (struct doc *)malloc(sizeof (struct doc));
        temp->strength = 1;
        strcpy(temp->specialization,specialization);
        temp->address = NULL;
        DocHead = temp;
        printf("\nDoctors Record Updated!");
    } else {
        while (z->address != NULL) {
            z = z->address;
        }
        com = SpecializationComparison(specialization, DocHead); // Function to compare specialization of doctors to increment the strength of doctors in a certain OPD if they have same specialization.
        if (com == 0) {
            printf("\nDoctors Record Updated!");
        } else {
            struct doc *temp = (struct doc *) malloc(sizeof(struct doc));
            temp->strength = 1;
            strcpy(temp->specialization, specialization);
            z->address = temp;
            temp->address = NULL;
            printf("\nDoctors Record Updated!");
        }
    }
}
void UpdateRecord(char name[20], int class) {  // Function to conduct patient appointment and update the record after appointment.
    struct node *p;
    struct node *q;
    int priority;
    if (class == 1) {
        priority = returnPriority(name, Vip1);  // Function to get priority of a certain patient in 1st VIP List
        if (priority >= 1) {
            printf("Appointment found with slot number %d", priority);
            if (priority == Vcount) {
                p = Vip1;
                Vip1 = Vip1->address;
                free(p); // Deleting the patient after appointment
                Vcount++; // Incrementing count to match the priority level.
                printf("\nAppointment Completed!");
            } else
                printf("\nPlease Wait! Your appointment is booked for slot %d", priority);
        } else {
            priority = returnPriority(name, Vip2); // Function to get priority of a certain patient in 2nd VIP List
            if (priority >= 1) {
                printf("Tomorrow's Appointment found with slot number %d.Please visit tomorrow!", priority);
            } else
                printf("\nAppointment not found!Please book the appointment");
        }
    } else {
        if (Vip1 !=NULL) // If patients are still present in VIP patients list
            printf("\nRegular Appointments not started yet.Please Wait!");
        else {
            priority = returnPriority(name, Regular1); // Function to get priority of a certain patient in 1st Regular List
            if (priority >= 1) {
                printf("Appointment found with slot number %d", priority);
                if (priority == Rcount) {
                    q = Regular1;
                    Regular1 = Regular1->address;
                    free(q); // Deleting the patient after appointment
                    Rcount++;  // Incrementing count to match the priority level.
                    printf("\nAppointment Completed!");
                } else
                    printf("\nPlease Wait! Your appointment is booked for slot %d", priority);
            } else {
                priority = returnPriority(name, Regular2); // Function to get priority of a certain patient in 2nd Regular List
                if (priority >= 1) {
                    printf("Tomorrow's Appointment found with slot number %d.Please visit tomorrow!", priority);
                } else
                    printf("\nAppointment not found!Please book the appointment");
            }
        }
    }
}
void bookAppointment(char name[20], int class,char OPD[15]) {  // Function to book appointments of patients
    struct node *p = Vip1;
    struct node *q = Regular1;
    struct node *r = Vip2;
    struct node *s = Regular2;
    int ch,com;
    if (class == 1) {
        if (p == NULL && VipCounter<numOfPatients) {  // list should be empty and Counter must be less than 10 to insert data in first node
            struct node *temp = (struct node *) malloc(sizeof(struct node));
            if(Vcount!=1){ // If list become null after deleting certain patients and then new patient is inserted then the value of Vcount is assigned as priority
                temp->priority = Vcount;
            } else
                temp->priority = 1; // Setting the priority of 1st patient to be one.
                strcpy(temp->name, name);
                strcpy(temp->category, "VIP");
                strcpy(temp->OPD, OPD);
                temp->address = NULL;
                Vip1 = temp;
                VipCounter++; // Incrementing the VIP patients list after booking of appointment.
                printf("\nAppointment Booked!");

        } else{
            if(VipCounter<numOfPatients) {  // If 10 patients are inserted then the loop will not operate otherwise condition becomes false.
                while (p->address != NULL) {
                    p = p->address;
                }
            }
            if (VipCounter < numOfPatients) {  // Maximum 10 VIP patients in a day
                struct node *temp = (struct node *) malloc(sizeof(struct node));
                temp->priority = VipCounter + 1; // Incrementing the new patient priority by one each time.
                // For comparison of names
                com = nameComparison(name,Vip1); //Function to compare names of two patients to make sure that two patients should not have same name.
                if(com == 0) {
                    printf("\nName Already exists. Enter name with modified initials or Surname!");
                    return;
                } else {
                    strcpy(temp->name, name);
                    strcpy(temp->category, "VIP");
                    strcpy(temp->OPD,OPD);
                    temp->address = NULL;
                    p->address = temp;
                    VipCounter++;
                    printf("\nAppointment Booked!");
                }
            } else {
                printf("\nNo appointments available today!");
                printf("\nDo you want to look for available appointment slot in next day?");
                printf("\n1-Yes\n2-No");
                scanf("%d", &ch);
                switch (ch) {
                    case 1:
                        if (class == 1) {
                            if (r == NULL && Vip2Counter<numOfPatients) { // list should be empty and Counter must be less than 10 to insert data in first node
                                struct node *temp = (struct node *) malloc(sizeof(struct node));
                                temp->priority = 1; // Setting the priority of 1st patient to be one.
                                strcpy(temp->name, name);
                                strcpy(temp->category, "VIP");
                                strcpy(temp->OPD,OPD);
                                temp->address = NULL;
                                Vip2 = temp;
                                Vip2Counter++;
                                printf("\nAppointment Booked!");
                            } else {
                                if(Vip2Counter<numOfPatients) { // If 10 patients are inserted then the loop will not operate otherwise condition becomes false.
                                    while (r->address != NULL) {
                                        r = r->address;
                                    }
                                }
                                if (Vip2Counter < numOfPatients) {
                                    struct node *temp = (struct node *) malloc(sizeof(struct node));
                                    temp->priority = Vip2Counter + 1; // Incrementing the new patient priority by one each time.
                                    // For comparison of names
                                    com = nameComparison(name,Vip2); //Function to compare names of two patients to make sure that two patients should not have same name.
                                    if(com == 0) {
                                        printf("\nName Already exists. Enter name with modified initials or Surname!");
                                        return;
                                    } else {
                                        strcpy(temp->name, name);
                                        strcpy(temp->category, "VIP");
                                        strcpy(temp->OPD,OPD);
                                        temp->address = NULL;
                                        r->address = temp;
                                        Vip2Counter++;
                                        printf("\nAppointment Booked!");
                                    }
                                } else {
                                    printf("\nNo appointments available This Week!Pleas Book Appointment in Next Week");

                                }
                            }
                        }
                        break;
                    case 2:
                        break;
                    default:
                        printf("\nEnter valid Option!");
                }
            }
        }
    }
        else {
        if (q == NULL && RegularCounter<numOfPatients) { // list should be empty and Counter must be less than 10 to insert data in first node
            struct node *temp = (struct node *) malloc(sizeof(struct node));
            if(Rcount!=1){ // If list become null after deleting certain patients and then new patient is inserted then the value of Rcount is assigned as priority
                temp->priority = Rcount;
            }else
            temp->priority = 1; // Setting the priority of 1st patient to be one.
            strcpy(temp->name, name);
            strcpy(temp->category, "Regular");
            strcpy(temp->OPD,OPD);
            temp->address = NULL;
            Regular1 = temp;
            RegularCounter++;
            printf("\nAppointment Booked!");
        } else{
            if(RegularCounter<numOfPatients) { // If 10 patients are inserted then the loop will not operate otherwise condition becomes false.
                while (q->address != NULL) {
                    q = q->address;
                }
            }
            if (RegularCounter < numOfPatients) { // Maximum 10 Regular patients in a day
                struct node *temp = (struct node *) malloc(sizeof(struct node));
                temp->priority = RegularCounter + 1; // Incrementing the new patient priority by one each time.
                // For comparison of names
                com = nameComparison(name,Regular1); //Function to compare names of two patients to make sure that two patients should not have same name.
                if(com == 0) {
                    printf("\nName Already exists. Enter name with modified initials or Surname!");
                    return;
                } else {
                    strcpy(temp->name, name);
                    strcpy(temp->category, "Regular");
                    strcpy(temp->OPD,OPD);
                    temp->address = NULL;
                    q->address = temp;
                    RegularCounter++;
                    printf("\nAppointment Booked!");
                }
            } else {
                printf("\nNo appointments available today!");
                printf("\nDo you want to look for available appointment slot in next day?");
                printf("\n1-Yes\n2-No");
                scanf("%d", &ch);
                switch (ch) {
                    case 1:
                        if (class == 2) {
                            if (s == NULL && Regular2Counter<numOfPatients) { // list should be empty and Counter must be less than 10 to insert data in first node
                                struct node *temp = (struct node *) malloc(sizeof(struct node));
                                temp->priority = 1;
                                strcpy(temp->name, name);
                                strcpy(temp->category, "Regular");
                                strcpy(temp->OPD,OPD);
                                temp->address = NULL;
                                Regular2 = temp;
                                Regular2Counter++;
                                printf("\nAppointment Booked!");
                            } else {
                                if(Regular2Counter<numOfPatients) { // If 10 patients are inserted then the loop will not operate otherwise condition becomes false.
                                    while (s->address != NULL) {
                                        s = s->address;
                                    }
                                }
                                if (Regular2Counter < numOfPatients) {
                                    struct node *temp = (struct node *) malloc(sizeof(struct node));
                                    temp->priority = Regular2Counter + 1; // Incrementing the new patient priority by one each time.
                                    // For comparison of names
                                    com = nameComparison(name,Regular2); //Function to compare names of two patients to make sure that two patients should not have same name.
                                    if(com == 0) {
                                        printf("\nName Already exists. Enter name with modified initials or Surname!");
                                        return;
                                    } else {
                                        strcpy(temp->name, name);
                                        strcpy(temp->category, "Regular");
                                        strcpy(temp->OPD,OPD);
                                        temp->address = NULL;
                                        s->address = temp;
                                        Regular2Counter++;
                                        printf("\nAppointment Booked!");
                                    }
                                } else {
                                    printf("\nNo appointments available This Week!Pleas Book Appointment in Next Week");

                                }
                            }
                        }
                        break;
                    case 2:
                        break;
                    default:
                        printf("\nEnter valid Option!");
                }
            }
        }
    }
}
void display(struct node *head) { // Function to display patients record
    struct node *p = head;
    printf("\nName \t\t\t  Priority \t\t\t Category \t\t OPD Type");
    while (p != NULL) {
        printf("\n%-10s\t\t\t %-12d\t\t %8s\t\t %8s\t", p->name, p->priority, p->category, p->OPD);
        p = p->address;
    }
}
void displayDoctors(struct doc *head){   // Function to display doctors record
    struct doc *p = head;
    printf("\nDepartment \t\t\tDoctors strength");
    while (p!=NULL){
        printf("\n%-10s\t\t\t%-12d",p->specialization,p->strength);
        p = p->address;
    }
}
void displayNurses(struct nurse *head){  // Function to display Nurses record
    struct nurse *p = head;
    printf("\nWard Type \t\t\tNurses strength");
    while (p!=NULL){
        printf("\n%-10s\t\t\t%-12d",p->Ward,p->strength);
        p = (struct nurse *) p->address;
    }
}void displayWards(struct ward *head){  // Function to display Wards and ICUs record
    struct ward *p = head;
    printf("\nWard Type \t\t\tWard strength");
    while (p!=NULL){
        printf("\n%-10s\t\t\t%-12d",p->WardType,p->strength);
        p = p->address;
    }
}void displayEquipment(struct equip *head){  // Function to display Hospital equipment record
    struct equip *p = head;
    printf("\nEquipment Type \t\t\tEquipment strength");
    while (p!=NULL){
        printf("\n%-10s\t\t\t%-12d",p->equipment,p->strength);
        p = p->address;
    }
}
int nameComparison(char name[SIZE],struct node *List) {  // Function for comparison of patients names
    struct node *p = List;
    int i = 0, j = 0, com;
    while (p != NULL) {
        while (p->name[i] != '\0') {      // Convert the both names in previous list and the newly inserted name to lowercase form and then comparing.
            if (p->name[i] >= 'A' && p->name[i] <= 'Z') {
                p->name[i] = p->name[i] + 32;
            }
            i++;
        }
        while (name[j] != '\0') {
            if (name[j] >= 'A' && name[j] <= 'Z') {
                name[j] = name[j] + 32;
            }
            j++;
        }
        com = strcmp(p->name, name);
        if(com == 0) {  // If names are same
            break;
        }else {
            p = p->address;
        }
    }
    if(com == 0){
        return com;
    } else
        return com;
}
int SpecializationComparison(char name[SIZE],struct doc *List) { // Function for comparison of specializations of doctors
    struct doc *p = List;
    int i = 0, j = 0, com;
    while (p != NULL) {
        while (p->specialization[i] != '\0') {
            if (p->specialization[i] >= 'A' && p->specialization[i] <= 'Z') {
                p->specialization[i] = p->specialization[i] + 32;
            }
            i++;
        }
        while (name[j] != '\0') {
            if (name[j] >= 'A' && name[j] <= 'Z') {
                name[j] = name[j] + 32;
            }
            j++;
        }
        com = strcmp(p->specialization, name);
        if(com == 0) {
            p->strength++;
            break;
        }else {
            p = p->address;
        }
    }
    if(com == 0){
        return com;
    } else
        return -1;
}int WardComparison(char name[SIZE],struct nurse *List) { // Function for comparison of ward names
    struct nurse *p = List;
    int i = 0, j = 0, com;
    while (p != NULL) {
        while (p->Ward[i] != '\0') {
            if (p->Ward[i] >= 'A' && p->Ward[i] <= 'Z') {
                p->Ward[i] = p->Ward[i] + 32;
            }
            i++;
        }
        while (name[j] != '\0') {
            if (name[j] >= 'A' && name[j] <= 'Z') {
                name[j] = name[j] + 32;
            }
            j++;
        }
        com = strcmp(p->Ward, name);
        if(com == 0) {
            p->strength++;
            break;
        }else {
            p = p->address;
        }
    }
    if(com == 0){
        return com;
    } else
        return -1;
}int EquipmentComparison(char name[SIZE],struct equip *List) {  // Function for comparison of Names of hospital equipment
    struct equip *p = List;
    int i = 0, j = 0, com;
    while (p != NULL) {
        while (p->equipment[i] != '\0') {
            if (p->equipment[i] >= 'A' && p->equipment[i] <= 'Z') {
                p->equipment[i] = p->equipment[i] + 32;
            }
            i++;
        }
        while (name[j] != '\0') {
            if (name[j] >= 'A' && name[j] <= 'Z') {
                name[j] = name[j] + 32;
            }
            j++;
        }
        com = strcmp(p->equipment, name);
        if(com == 0) {
            p->strength++;
            break;
        }else {
            p = p->address;
        }
    }
    if(com == 0){
        return com;
    } else
        return -1;
}
int returnPriority(char name[SIZE],struct node *List) {  // Function to return priority of a specific patient for conduction of appointments.
    struct node *p = List;
    int i = 0, j = 0, com;
    while (p != NULL) {
        while (p->name[i] != '\0') {
            if (p->name[i] >= 'A' && p->name[i] <= 'Z') {
                p->name[i] = p->name[i] + 32;
            }
            i++;
        }
        while (name[j] != '\0') {
            if (name[j] >= 'A' && name[j] <= 'Z') {
                name[j] = name[j] + 32;
            }
            j++;
        }
        com = strcmp(p->name, name);
        if(com == 0) {
            break;
        }else {
            p = p->address;
        }
    }
    if(com == 0){
        return p->priority;
    } else
        return -1;
}
